# FullStackGEU


### Hi 👋 
This is the repository made for the assignments and other task assigned during the course FULL STACK WEB DEVELOPMENT.

## 𝗪𝗵𝗮𝘁 𝗜 𝗨𝘀𝗲

![C](https://img.shields.io/badge/-C-000?&logo=C)
![C++](https://img.shields.io/badge/-C++-00599C?style=flat-square&logo=c)
![JavaScript](https://img.shields.io/badge/-JavaScript-black?style=flat-square&logo=javascript)
![Java](https://img.shields.io/badge/-java-E34A86?style=flat-square&logo=java)
![HTML5](https://img.shields.io/badge/-HTML5-E34F26?style=flat-square&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/-CSS3-1572B6?style=flat-square&logo=css3)
![Bootstrap](https://img.shields.io/badge/-Bootstrap-563D7C?style=flat-square&logo=bootstrap)


<h1 align="center">
  <img height="500px" src="FullStackWeb.jpg"/>
</h1>
